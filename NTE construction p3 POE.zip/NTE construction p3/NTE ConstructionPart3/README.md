# NTE Construction Website — Part 3 (POE)

A responsive five-page website project for the NTE Construction residential-renovation assignment. The project includes HTML5, CSS3, vanilla JavaScript, SEO metadata, interactive features, client-side form validation, a Leaflet/OpenStreetMap service-area map, and deployment support files.

> **Assignment context:** NTE Construction is the fictional organisation described in the assignment scenario. Contact details, locations and business claims must be verified or kept clearly identified as assignment information before any real-world publication. The map pins show broad Gauteng service areas, not verified office addresses.

## 1. Project structure

```text
NTE_Construction_Part3/
├── index.html
├── about.html
├── services.html
├── enquiry.html
├── contact.html
├── CSS/
│   └── styles.css
├── JS/
│   └── script.js
├── Images/
│   ├── NTE logo.png
│   └── original and SEO-friendly image assets
├── Documents/
│   └── NTE Construction Website Proposal.docx
├── Screenshot/
├── robots.txt
├── sitemap.xml
└── README.md
```

## 2. Run locally

1. Extract the ZIP archive.
2. Open the `NTE Construction p3` folder in Visual Studio Code.
3. Keep the folder names and capitalisation (`CSS`, `JS`, `Images`, `Documents`, `Screenshot`) unchanged. Web servers can be case-sensitive.
4. Open `index.html` with the VS Code Live Server extension.
5. Test all navigation links and features.

The site has no build step or package installation. An internet connection is required for the Leaflet library, OpenStreetMap map tiles and WhatsApp/email hand-off links.

## 3. Pages

- `index.html` — Home page and FAQ accordion.
- `about.html` — Company background, mission, vision and values.
- `services.html` — Renovation service cards, live search, category filters, image lightbox and budget/contingency calculator.
- `enquiry.html` — Renovation enquiry form with required fields, validation and a WhatsApp message hand-off.
- `contact.html` — General contact form, email-draft hand-off and interactive Gauteng service-area map.

## 4. Part 3 functionality

- Responsive mobile navigation with an accessible expanded/collapsed state.
- FAQ accordion with `aria-expanded` state.
- Search and category filtering for the service cards; visible result count and no-results message update dynamically.
- Keyboard-accessible image lightbox; close with the close button, Escape key or backdrop.
- Scroll reveal animations, respecting reduced-motion preferences in CSS.
- Renovation budget calculator with a configurable contingency percentage.
- Back-to-top button.
- Leaflet interactive map with OpenStreetMap tiles and indicative markers for Johannesburg, Centurion and Pretoria. These markers are city/service-area markers, not exact office pins.
- Enquiry and contact form client-side validation, field-level messages, consent validation, email/phone checks, minimum text lengths and future-date validation.

## 5. Form behaviour and contact settings

The WhatsApp number is configured in `JS/script.js`:

```js
const WHATSAPP_NUMBER = "27728537594";
```

The enquiry form validates the submitted information and creates a pre-filled WhatsApp message. The visitor must review the message and press **Send** in WhatsApp. The website cannot silently send WhatsApp messages using a normal `wa.me` link.

The general Contact form validates the information and creates a pre-filled email draft addressed to:

```js
const CONTACT_RECIPIENT = "info@nteconstruction.co.za";
```

The visitor selects the generated email link, their configured email application opens with the subject and message populated, and the visitor presses **Send**. A `mailto:` link does not send an email automatically and depends on the visitor having an email application configured. For true server-side/AJAX delivery, connect a verified email service or backend endpoint and protect its credentials; do not place private API keys in front-end JavaScript.

No form submission is stored in a database. The website does not include customer accounts, online payments, confirmed booking availability or automatic email/WhatsApp delivery.

## 6. SEO and accessibility work

- Each page has a unique title, meta description and assignment-requested meta keywords.
- Pages use semantic headings, a language declaration, a mobile viewport, internal navigation and a skip-to-content link.
- Images use descriptive alternative text; service images also have descriptive SEO-friendly filename copies.
- Responsive layouts and reduced-motion support are included.
- `robots.txt` and `sitemap.xml` are included. Replace `YOUR-LIVE-DOMAIN` in both files after deployment.
- Compress large images/video before production deployment to improve page speed. The supplied `Images/videoQ.mp4` is large; remove it if unused or provide a compressed version.
- Use HTTPS on the hosting platform and keep third-party libraries updated. Form validation is for usability, not a substitute for server-side security.

**SEO note:** The assignment rubric asks for meta keywords, so they are included. Major search engines may ignore the meta-keywords tag; useful page content, titles, descriptions, accessibility, performance and reputable links matter more.

## 7. Changelog

### Part 2 feedback corrections and review — 28 October 2026
- Standardised the local JavaScript reference to `JS/script.js` with the `defer` attribute on all five pages.
- Normalised HTML Boolean attributes such as `required`, `hidden` and `novalidate`.
- Replaced unverified street addresses and telephone numbers on the Contact page with Gauteng service-area descriptions; the map is explicitly labelled as indicative rather than an exact business location.
- Updated the home-page hero image alternative text and improved renovation image descriptions.
- Added SEO-friendly copies of service image files while retaining the supplied original image assets.
- Added robots indexing directives and retained the sitemap template for completion after deployment.

### Part 3 functionality and SEO — 28 October 2026
- Reworked the JavaScript into separate feature functions and added defensive checks where page elements may not exist.
- Improved mobile navigation accessibility and filter button pressed states.
- Implemented/retained the FAQ accordion, service search and category filters, live result count, no-results message, keyboard-accessible gallery lightbox, scroll reveal effects, budget calculator and back-to-top control.
- Added a Leaflet interactive map using OpenStreetMap tiles with broad Johannesburg, Centurion and Pretoria service-area markers.
- Added field-level form validation, accessible invalid states, email and telephone checks, minimum text lengths, consent checks and future-date validation.
- Kept the renovation Enquiry form on WhatsApp and added a separate Contact form email-draft flow addressed to the configured recipient.
- Added page-level `robots` metadata and updated the README with project structure, test guidance, form limitations, SEO notes, deployment instructions and references.

### Deployment preparation
- Added `robots.txt` and `sitemap.xml`; replace the `YOUR-LIVE-DOMAIN` placeholder with the actual published domain before submitting the live URL.
- Added `.gitignore` for common local/editor files.

## 8. Testing checklist

- [ ] Open each of the five HTML pages locally and on the deployed URL.
- [ ] Check all navigation links, logo link, footer links and skip link.
- [ ] Test the mobile menu at narrow screen widths.
- [ ] Search for services; test each category filter and a no-results search.
- [ ] Open a gallery image using mouse and keyboard; close with button, Escape and backdrop.
- [ ] Open and close each FAQ item.
- [ ] Test the budget calculator with a valid positive budget and invalid/empty input.
- [ ] Submit each form empty; confirm errors appear and focus moves to an invalid field.
- [ ] Test invalid email, invalid phone, short message, missing consent and a past date.
- [ ] Submit a valid enquiry and check that WhatsApp opens with the correct pre-filled details.
- [ ] Submit a valid contact message and check that the email draft contains the correct recipient, subject and message. Press Send only in a test environment or after confirming the recipient.
- [ ] Confirm the Leaflet map and map markers load when online.
- [ ] Check that all images load and all pages work on a phone.
- [ ] Run the browser developer console and fix any remaining errors.

## 9. GitHub and free deployment

1. Create a GitHub repository and push the complete project folder.
2. Commit work in meaningful stages, for example: `Update Part 2 feedback`, `Add Part 3 JavaScript interactions`, `Implement map and form validation`, `Improve SEO and README`, and `Prepare deployment`.
3. Deploy the folder using Netlify (drag-and-drop deployment or GitHub integration) or GitHub Pages. For GitHub Pages, select the correct branch and project root in repository Pages settings.
4. After deployment, update `sitemap.xml` and `robots.txt` with the actual live domain.
5. Test every page and submit both the GitHub repository URL and published website URL if requested by the lecturer.

## 10. References

The following documentation/resources were used or are relevant to the implemented features (accessed 2 November 2026):

- MDN Web Docs, HTML forms and constraint validation: https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms/Form_validation
- MDN Web Docs, JavaScript DOM: https://developer.mozilla.org/en-US/docs/Web/API/Document_Object_Model
- MDN Web Docs, Intersection Observer API: https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API
- Leaflet documentation: https://leafletjs.com/reference.html
- OpenStreetMap copyright and attribution: https://www.openstreetmap.org/copyright
- Google Search Central, SEO starter guide: https://developers.google.com/search/docs/fundamentals/seo-starter-guide
- Google Search Central, sitemap overview: https://developers.google.com/search/docs/crawling-indexing/sitemaps/overview
- W3Schools, HTML images: https://www.w3schools.com/html/html_images.asp
- GitHub Pages documentation: https://docs.github.com/en/pages



